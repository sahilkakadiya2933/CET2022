use Assignment3;

insert into student (`student_id`, `student_name`, `address`, `email`, `Legal_guardian` ,`gender`)
values (101, 'Sahil', 'navaho', 'skkakadiya@gmail.com', 'uncle', 'male'),
(102, 'kunj', 'navaho', 'kunjpatel@gmail.com', 'uncle', 'male'),
(103, 'kushal', 'baseline', 'kushalll@gmail.com', 'unty', 'male'),
(104, 'meet', 'baseline', 'meetkotadiya@gmail.com', 'uncle', 'male'),
(105, 'romin', 'bayshore', 'rominpatel@gmail.com', 'unty', 'male');

insert into Legal_Guardian(`LG_id`,`home_phone`,`gender`,`address`,`LG_name`, `Children_responsible`)
values (01, 12453258, 'male', 'baseline', 'sam', 'self'),
(02, 14253678, 'male', 'baseline', 'rom', 'self'),
(03, 14589745, 'male', 'merival', 'jay', 'self'),
(04, 78457845, 'male', 'merival', 'ram', 'self'),
(05, 45123652, 'male', 'bayshore', 'john', 'self');

insert into enrollements(`GPA_for_each_academic_year`,`Homeroom_teacher`,`Location_of_each_course`, `Course_enrolled_in`,`Homeroom_location`,`Overall_GPA`)
values (2003, 'mike' , 'B356', 'CST', 'baseline', 4),
(2002, 'mike' , 'B120',' CST', 'baseline', 3),
(2001, 'Roly Roy' , 'B125',' CST', 'navaho', 4),
(2004, 'Roly Roy' , 'B128',' CST', 'beyshore', 2),
(2002, 'Roly Roy' , 'B124',' CST', 'merivel', 4);

insert into Post_Highschool_Plan(`Result_of_application`, `College`, `Colleges`)
values (80, 'Ld College', 'government'),
(85, 'IIT bombay', 'private'),
(95, 'IIT delhi', 'private'),
(89, 'Dharuka college', 'private'),
(78, 'Sasit', 'government');

insert into EXTRA_CURRICULAR_ACTIVITIES(`Id_of_Student`,`Academic_Year`,`Number_of_Clubs`,`Position_held`)
values(11, 2001, 5, 'manager'),
(12, 2002, 6, 'employee'),
(13, 2001, 8, 'worker'),
(14, 2003, 15, 'peon'),
(15, 2002, 25, 'supervisior');

insert into STANDARDIZED_TESTING_RESULT (`Result_of_test`,`Name_of_Student`,`Name_of_test`)
values(80, 'sahil', 'english'),
(85, 'meet', 'maths'),
(87, 'man', 'physics'),
(70, 'kushal', 'chemistry'),
(75, 'romin', 'biology');

insert into DISCIPLINARY_ACTION (`student_id`,`Name_of_Student`,`LG_id`,`Type_of_incident`,`Disciplinary_action_taken`)
values(101, 'roy',01, 'by car', 'to stay safe'),
(102, 'jassy', 02, 'by truck', 'to follow traffic rules'),
(103, 'ronit', 03, 'by motorbike', 'to follow road sign'),
(104, 'kunj', 04, 'by car', 'to safe driving'),
(105, 'rohan', 05, 'by truck', 'to keep safe');
