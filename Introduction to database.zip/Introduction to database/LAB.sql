create database lab6;

use lab6;
create table Customer (
	Cus_id int primary key, 
    Cus_Name varchar( 25 ), 
    Cus_Email varchar( 150 ),
    Cus_Phone int( 20 ),
    Cus_street_Address varchar( 50 ),
    Cus_City varchar( 30 ),
    Cus_Province char( 2 ),
    Cus_PostCode char( 6 ),
    CONSTRAINT Cus_PK PRIMARY KEY( Cus_id )
    );
    insert into Customer values (
    101, "Sahil", "skkakadiya29@gmail.com", 343-558-3678, "Baseline Road", "Ottawa", "ON", "K2C3N1");
    