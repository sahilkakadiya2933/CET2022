create database Assignment3;

use Assignment3;

create table student (
student_id        INT             NOT NULL auto_increment,
student_name               varchar(50)     NOT NULL,
address            varchar(50)     NOT NULL,
email              varchar(50)     not null,
Legal_guardian     varchar(20)         NOT NULL,
gender			   varchar(5)      Not null,
CONSTRAINT 		   studentpk 	   primary key(student_id),
CONSTRAINT 		   studentak1 	   UNIQUE(student_name)
);

create table Legal_Guardian (
LG_id          int               not null,
home_phone     int(20)            not null,
gender         varchar(50)    not null,
address        varchar(50)    not null,
LG_name           varchar(50)    not null,
Children_responsible varchar(50) not null,
Constraint  Legal_Guardianpk   primary key(LG_id),
constraint  Legal_Guardianak1  unique(LG_name)
);

create table enrollements (
GPA_for_each_academic_year        int           not null,
Homeroom_teacher                  varchar(50)   not null,
Location_of_each_course           varchar(50)   not null,
Course_enrolled_in                varchar(50)   not null,
Homeroom_location                 varchar(50)   not null,
Overall_GPA                       varchar(50)   not null,
constraint enrollementspk primary key(Overall_GPA),
constraint enrollementak1 unique(Homeroom_teacher)
);

create table Post_Highschool_Plan (
Result_of_application      int           not null,
College                    varchar(50)   not null,
Colleges                   varchar(50)   not null,
constraint Post_Highschool_Planpk    primary key(Result_of_application)
);

create table EXTRA_CURRICULAR_ACTIVITIES (
Id_of_Student    int          not null,
Academic_Year      int(5)      not null,
Number_of_Clubs    int          not null,
Position_held      varchar(50)  not null,
constraint EXTRA_CURRICULAR_ACTIVITIESpk    primary key(Id_of_Student),
constraint EXTRA_CURRICULAR_ACTIVITIESak1   unique(Position_held)
);

create table STANDARDIZED_TESTING_RESULT (
Result_of_test       varchar(100)          not null,
Name_of_Student      varchar(50)           not null,
Name_of_test         varchar(50)           not null,
constraint STANDARDIZED_TESTING_RESULTpk  primary key(Result_of_test),
constraint STANDARDIZED_TESTING_RESULTak1 unique(Name_of_Student)
);

create table DISCIPLINARY_ACTION (
student_id           int                not null,
Name_of_Student               varchar(50)       not null,
LG_id                 int               not null,
Type_of_incident           varchar(50)       not null,
Disciplinary_action_taken  varchar(50)       not null,
constraint DISCIPLINARY_ACTION_pk  primary key(Name_of_Student),
constraint student_fk1     foreign key(student_id) references student(student_id),
constraint Legal_Guardian_fk2   foreign key(LG_id) references Legal_Guardian(LG_id)
);

