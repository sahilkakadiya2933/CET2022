/*
 * Assessment: Lab exercise 1
 * Student Name: Sahil Kakadiya
 * Lab Professor Name: Leanne seaward
 * Lab Section Number: 303 
 * Due date : 24th June
 * Description : find a hypotenuse, Perimeter, Surface Area using a java code. 
*/
import java.util.Scanner;


public class TestRightAngleTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		RightAngleTriangle R1 = new RightAngleTriangle();
		
		
		//creating a scanner object
		
		Scanner keyboard = new Scanner (System.in);
		
		//create a Traingle using the no-argument constructor
		
		System.out.println("Enter The Adjacentside is :");
		double Adjacentside = keyboard.nextDouble();
		
		System.out.println("Enter The Oppositeside is : ");
		double Oppositeside = keyboard.nextDouble();
		
		R1.setAdjacentside(Adjacentside);
		
		
		R1.setOppositeside(Oppositeside);
		

		R1.calculatehypotenuse();
		
		R1.calculatePerimeter();
		R1.calculateSurfaceArea();
		R1.RightAngleTriangleReport();
		System.out.println("Program by Sahil Kakadiya");


	}

}
