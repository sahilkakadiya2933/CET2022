/*
 * Assessment: Lab exercise 1
 * Student Name: Sahil Kakadiya
 * Lab Professor Name: Leanne seaward
 * Lab Section Number: 303 
 * Due date : 24th June
 * Description : find a hypotenuse, Perimeter, Surface Area using a java code. 
*/
import java.text.DecimalFormat;
public class RightAngleTriangle { 
	
	//private constructor added
	
	private double Adjacentside;
	private double Oppositeside;
	private double hypotenuse;
	private double Perimeter;
	private double Surfacearea;
	
	
	//no argument constructor
	
	public RightAngleTriangle() {
		
	}
	
	public void setAdjacentside(double Adjacentside) {
		this.Adjacentside = Adjacentside;
	}
	
	public void setOppositeside(double Oppositeside) {
		this.Oppositeside = Oppositeside;
	}
	
	public double getAdjacentside() {
		return this.Adjacentside;
	}
	
	public double getOppositeside() {
		return this.Oppositeside;
	}
	
	public double hypotenuse() {
		return this.hypotenuse;
	}
	public double getPerimeter() {
		return this.Perimeter;
	}
	
	
	
	public double getSurfacearea() {
		return this.Surfacearea;
	}
	
	@Override
	
	public String toString() {
		return "RightAngleTriangle [Adjacentside="+Adjacentside+",Oppositeside="+Oppositeside+",hypotenuse="+hypotenuse+",Perimeter="+Perimeter+",Surfacearea="+Surfacearea+"]";
	}
	
	//worker method
	
	public void calculatehypotenuse() {

		this.hypotenuse = Math.hypot(this.Adjacentside, this.Oppositeside);
		
		
	}
	
	//worker method
	
	public void calculatePerimeter() {
		
		this.Perimeter = (this.Adjacentside + this.Oppositeside + this.hypotenuse);
		
	}
	
	//worker method 
	
	public void calculateSurfaceArea() {
		
		this.Surfacearea = (this.Adjacentside*this.Oppositeside)/2;
		
		
	}
	
	public void RightAngleTriangleReport() {
		System.out.println("Right Triangle Report : ");
		System.out.format("Adjacentside is : %.4f , ",+this.Adjacentside, " Oppositeside is : %.4f, ",+this.Oppositeside, " hypotenuse is : %.4f ",+this.hypotenuse);
		System.out.format("Oppositeside is : %.4f %n",+this.Oppositeside);
		System.out.format("hypotenuse is : %.4f %n",+this.hypotenuse);
		System.out.format("Perimeter is : %.4f %n",+this.Perimeter);
		System.out.format("Surface Area is : %.4f %n ",+this.Surfacearea);
	
	}
	
}
	
	
	

