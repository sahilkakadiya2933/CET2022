import java.util.Scanner;

public class Testtable {

	public static void main(String[] args) {
		
		Table t1 = new Table();
		System.out.println(t1.toString());
		
		t1.setDiameter(42.5);
		t1.setNumberOfCoats(4);
		
		System.out.println(t1.toString());
		
		System.out.println("Diameter is " +t1.getDiameter());
		System.out.println("Number Of Coats are " +t1.getNumberOfCoats());
		
		t1.calculateAreaOfCircle();
		
		
		t1.calculateTotalAreaOfCircle();
				
		t1.calculateTablesPerCan();
		
		t1.WorkReport();
		
		//creating scanner object for keyword input
		Scanner input = new Scanner(System.in);
		
		//create a Table using the no-arg constructor

		System.out.println("Enter The Diameter is : ");
		double diameter = input.nextDouble();
		
		System.out.println("Enter The Number Of Coats are : ");
		double numberofcoats = input.nextDouble();
		
		Table t2 = new Table();
		
		t2.setDiameter(diameter);
		t2.setNumberOfCoats(numberofcoats);
		
		System.out.println(t2.toString());
		
		System.out.println("Diameter is " +t1.getDiameter());
		System.out.println("Number Of Coats are " +t1.getNumberOfCoats());
		
		t2.calculateAreaOfCircle();
		
		
		t2.calculateTotalAreaOfCircle();
				
		t2.calculateTablesPerCan();
		
		t2.WorkReport();
		
		System.out.println("Program implemented by Sahil Kakadiya");
		
		
	}	
}
