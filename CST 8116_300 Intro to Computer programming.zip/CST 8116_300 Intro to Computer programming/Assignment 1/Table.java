
public class Table {
	
	private double diameter;
	private double numberofcoats;
	private double AreaOfCircle;
	private double TotalAreaOfCircle;
	private double TablesPerCan;
	
	//no argument constructor
	public Table() {
		
	}
	
	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}
	
	public void setNumberOfCoats(double numberofcoats) {
		this.numberofcoats = numberofcoats;
	}
	
	public double getDiameter() {
		return this.diameter;
	}
	
	public double getNumberOfCoats() {
		return this.numberofcoats;
	}
	
	public double getAreaPfCircle() {
		return this.AreaOfCircle;
	}
	
	public double getTotalAreaOfCircle() {
		return this.TotalAreaOfCircle;
	}
	
	public double getTablesPerCan() {
		return this.TablesPerCan;
	}
	
	
	@Override
	public String toString() {
		return "Table [diameter="+diameter+", numberofcoats="+numberofcoats+", AreaOfCircle="+AreaOfCircle+", TablesPerCan="+TablesPerCan+"]";
	}
	
	//worker method
	
	public void calculateAreaOfCircle() {
		 this.AreaOfCircle = (Math.PI*diameter*diameter)/4;
		
	}
	
	//worker method
	
	public void calculateTotalAreaOfCircle() {
		this.TotalAreaOfCircle = this.AreaOfCircle*this.numberofcoats;
	}
	
	//worker method
	
	public void calculateTablesPerCan() {
		this.TablesPerCan = 46800/this.TotalAreaOfCircle;
	}
	
	public void WorkReport() {
		System.out.println("Work Report\nDiameter is " + this.diameter);
		System.out.println("Number Of Coats are " + this.numberofcoats);
		System.out.println("Area of Circle is " + this.AreaOfCircle);
		System.out.println("Total Area of Circle is " + this.TotalAreaOfCircle);
		System.out.println("Tables Per Can is " + this.TablesPerCan);
	}
	
//calculateAreaOfCircle(): void
//calculateTotalAreaOfCircle(): void	
//calculateTablesPerCan(): void	
	
}
