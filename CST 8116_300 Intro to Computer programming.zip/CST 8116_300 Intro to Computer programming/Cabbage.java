
public class Cabbage {
	public static void main (String[] args) {
		
	}
	
		
		private double weight;
		private double costPerKilogram;
		private double price;
	
		
		
	
		public Cabbage() {
        }
		
		public void setWeight (double weight) {
			this.weight = weight;
		}
		public double getweight() {
			return this.weight;
		}
		
		
		
		
		 
		
		public void setCostPerKilogram (double costPerKilogram) {
			this.costPerKilogram = costPerKilogram;
		}
		public double getcostPerKilogram() {
			return this.costPerKilogram;
		}
		
		
		
		public double getprice() {
			return this.price;
		}
		
		
		public void printReport() {
			
			System.out.println("Print Report :\nweight is " + this.weight);
			System.out.println("Cost per Kilogram is " + this.costPerKilogram);
			System.out.println("Price is $" + this.price);
			System.out.println("Rominkumar Patel");
		}
		
			
			//worker method
			    public void calculatePrice() {
				double Kilogram = this.weight/1;
				this.price = Kilogram * this.costPerKilogram;
		
		}
		
	}


