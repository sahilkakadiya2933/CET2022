import java.util.Scanner;

public class TestCabbage {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the weight is: ");
		double weight = scan.nextDouble();
		
		System.out.println("Enter the CostPerKilogram is: ");
		double costPerKilogram = scan.nextDouble();
		
		
	Cabbage c1 = new Cabbage();
	
	c1.setWeight(weight);
	c1.setCostPerKilogram(costPerKilogram);
	
	c1.calculatePrice();
	
	c1.printReport();

	System.out.println("Program by Sahil Kakadiya");
	
	}
}
	
	
	
	
	
	
	