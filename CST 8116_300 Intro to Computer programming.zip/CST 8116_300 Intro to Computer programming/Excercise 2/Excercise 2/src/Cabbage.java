
public class Cabbage {

	
	private double weight;
	private double costPerKilogram;
	private double price;
	
	
	//no argument constructor
	public Cabbage() {
		
	}
	
	public void setWeight (double weight) {
		this.weight = weight;
	}
	
	public void setCostPerKilogram (double costPerKilogram) {
		this.costPerKilogram = costPerKilogram;
	}
	
	public double getweight() {
		return this.weight;
	}
	
	public double getcostPerKilogram() {
		return this.costPerKilogram;
	}
	
	public double getprice() {
		return this.price;
	}
	
	
	public void printReport() {
		
		System.out.println("Print Report :\nweight is " + this.weight);
		System.out.println("Cost per Kilogram is " + this.costPerKilogram);
		System.out.println("Price is $" + this.price);
	}
		
		//worker method
		public void calculatePrice() {
			double Kilogram = this.weight/1;
			this.price = Kilogram * this.costPerKilogram;
		
	}
	
	//calculatePrice() : void
	//printReort() : void
	
}
	
	
	
	
	